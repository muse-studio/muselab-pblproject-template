# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [82.0.1] - 2019-12-02
## Fixed
- 和文ドライバの指定ミスを修正

## [82.0.0] - 2019-12-02
### Add
- `\title` の拡張
- `\author` の拡張
- `\maketitle` の再定義
- フォントサイズの調整
- ページ余白の調整
